SELECT * FROM workers WHERE id IN(3,5,6,10)
